// < !--{% comment %} var postReq = new XMLHttpRequest();
// postReq.open("POST", "/orders/", true);
// const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;
// postReq.setRequestHeader("X-CSRFToken", csrftoken, 'Content-Type', 'application/integer');
// postReq.send(h); {% endcomment %} -->